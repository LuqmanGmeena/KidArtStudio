import React, { useState } from 'react';
import { Palette, Users, DollarSign, Settings, Home, Trophy } from 'lucide-react';
import Header from './components/Header';
import DrawingCanvas from './components/DrawingCanvas';
import Gallery from './components/Gallery';
import Profile from './components/Profile';
import Subscription from './components/Subscription';

function App() {
  const [activeTab, setActiveTab] = useState('draw');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [user, setUser] = useState(null);

  const tabs = [
    { id: 'draw', label: 'Draw', icon: Palette },
    { id: 'gallery', label: 'Gallery', icon: Users },
    { id: 'earnings', label: 'Earnings', icon: DollarSign },
    { id: 'profile', label: 'Profile', icon: Settings },
  ];

  const renderContent = () => {
    if (!user) {
      return <Subscription onUserLogin={setUser} onSubscribe={setIsSubscribed} />;
    }

    if (!isSubscribed) {
      return <Subscription onUserLogin={setUser} onSubscribe={setIsSubscribed} user={user} />;
    }

    switch (activeTab) {
      case 'draw':
        return <DrawingCanvas />;
      case 'gallery':
        return <Gallery />;
      case 'earnings':
        return <EarningsPage user={user} />;
      case 'profile':
        return <Profile user={user} />;
      default:
        return <DrawingCanvas />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-50 to-yellow-100">
      <Header user={user} />
      
      <main className="container mx-auto px-4 py-8">
        {user && isSubscribed && (
          <nav className="flex justify-center mb-8">
            <div className="bg-white rounded-full p-2 shadow-lg flex space-x-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center space-x-2 px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                      activeTab === tab.id
                        ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-md transform scale-105'
                        : 'text-gray-600 hover:bg-gray-100 hover:text-purple-600'
                    }`}
                  >
                    <Icon size={20} />
                    <span className="hidden sm:inline">{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </nav>
        )}

        <div className="max-w-6xl mx-auto">
          {renderContent()}
        </div>
      </main>

      {user && isSubscribed && (
        <div className="fixed bottom-6 right-6">
          <div className="bg-white rounded-full p-4 shadow-lg border-4 border-yellow-300">
            <Trophy className="w-8 h-8 text-yellow-500" />
          </div>
        </div>
      )}
    </div>
  );
}

export default App;