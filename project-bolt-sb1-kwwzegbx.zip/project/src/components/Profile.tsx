import React from 'react';
import { TrendingUp, Award, Calendar, DollarSign, Target, Star, Settings, Bell, Shield, Gift, Camera, Users, BookOpen, Zap } from 'lucide-react';

interface ProfileProps {
  user: any;
}

const Profile: React.FC<ProfileProps> = ({ user }) => {
  const [activeSection, setActiveSection] = React.useState('overview');
  
  const stats = [
    { label: 'Total Earnings', value: '2,450 Tsh', icon: DollarSign, color: 'text-green-600', bg: 'bg-green-100' },
    { label: 'Drawings Created', value: '28', icon: Target, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Days Active', value: '15', icon: Calendar, color: 'text-purple-600', bg: 'bg-purple-100' },
    { label: 'Artist Level', value: 'Level 3', icon: Star, color: 'text-yellow-600', bg: 'bg-yellow-100' }
  ];

  const achievements = [
    { title: 'First Drawing', description: 'Created your first masterpiece', earned: true, icon: '🎨' },
    { title: 'Nature Lover', description: 'Drew 5 nature scenes', earned: true, icon: '🌿' },
    { title: 'Daily Artist', description: 'Drew for 7 days in a row', earned: true, icon: '📅' },
    { title: 'Popular Creator', description: 'Got 100 likes total', earned: false, icon: '❤️' },
    { title: 'Earning Star', description: 'Earned 1000 Tsh', earned: false, icon: '⭐' },
    { title: 'Community Favorite', description: 'Top 10 artist this month', earned: false, icon: '🏆' }
  ];

  const recentEarnings = [
    { drawing: 'Sunset Garden', amount: '180 Tsh', date: 'Today' },
    { drawing: 'My School', amount: '220 Tsh', date: 'Yesterday' },
    { drawing: 'Rain Day', amount: '160 Tsh', date: '2 days ago' },
    { drawing: 'Family Picnic', amount: '290 Tsh', date: '3 days ago' },
    { drawing: 'City Street', amount: '340 Tsh', date: '4 days ago' }
  ];

  const friends = [
    { name: 'Ahmed', age: 10, level: 'Level 2', avatar: 'A', status: 'online' },
    { name: 'Grace', age: 9, level: 'Level 4', avatar: 'G', status: 'offline' },
    { name: 'John', age: 7, level: 'Level 1', avatar: 'J', status: 'online' },
    { name: 'Amara', age: 11, level: 'Level 5', avatar: 'A', status: 'drawing' }
  ];

  const tutorials = [
    { title: 'Drawing Trees', duration: '5 min', completed: true, icon: '🌳' },
    { title: 'Color Mixing', duration: '8 min', completed: true, icon: '🎨' },
    { title: 'Drawing Animals', duration: '12 min', completed: false, icon: '🐕' },
    { title: 'Perspective Basics', duration: '15 min', completed: false, icon: '🏠' }
  ];

  const profileSections = [
    { id: 'overview', label: 'Overview', icon: Target },
    { id: 'friends', label: 'Friends', icon: Users },
    { id: 'learning', label: 'Learning', icon: BookOpen },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <div className="bg-gradient-to-r from-purple-500 via-pink-500 to-yellow-500 rounded-2xl p-8 text-white">
        <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6">
          <div className="w-24 h-24 bg-white bg-opacity-20 rounded-full flex items-center justify-center border-4 border-white">
            <span className="text-4xl font-bold">
              {user?.name?.charAt(0).toUpperCase() || 'K'}
            </span>
          </div>
          <div className="text-center md:text-left flex-1">
            <h1 className="text-3xl font-bold mb-2">{user?.name || 'Young Artist'}</h1>
            <p className="text-lg opacity-90 mb-3">Creative Explorer • Level 3 Artist</p>
            <div className="flex items-center justify-center md:justify-start space-x-2">
              <Star className="w-5 h-5" />
              <span className="font-medium">Member since December 2024</span>
            </div>
          </div>
        </div>
      </div>

      {/* Profile Navigation */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="flex border-b border-gray-200">
          {profileSections.map((section) => (
            <button
              key={section.id}
              onClick={() => setActiveSection(section.id)}
              className={`flex-1 flex items-center justify-center space-x-2 py-4 px-6 font-medium transition-all duration-200 ${
                activeSection === section.id
                  ? 'bg-purple-500 text-white'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-purple-600'
              }`}
            >
              <section.icon size={18} />
              <span className="hidden sm:inline">{section.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Stats Grid */}
      {activeSection === 'overview' && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
              <div className={`w-12 h-12 ${stat.bg} rounded-full flex items-center justify-center mb-4 mx-auto`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-800 mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Friends Section */}
      {activeSection === 'friends' && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center space-x-2">
              <Users className="w-6 h-6 text-blue-600" />
              <span>Art Friends</span>
            </h3>
            <div className="grid md:grid-cols-2 gap-4">
              {friends.map((friend, index) => (
                <div key={index} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-all duration-200">
                  <div className="relative">
                    <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full flex items-center justify-center text-white font-bold">
                      {friend.avatar}
                    </div>
                    <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${
                      friend.status === 'online' ? 'bg-green-400' : 
                      friend.status === 'drawing' ? 'bg-blue-400' : 'bg-gray-400'
                    }`}></div>
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-gray-800">{friend.name}, Age {friend.age}</div>
                    <div className="text-sm text-gray-600">{friend.level} • {friend.status}</div>
                  </div>
                  <button className="px-3 py-1 bg-purple-100 text-purple-700 text-sm font-medium rounded-full hover:bg-purple-200 transition-all duration-200">
                    View Art
                  </button>
                </div>
              ))}
            </div>
            <button className="w-full mt-4 bg-blue-100 hover:bg-blue-200 text-blue-700 font-medium py-3 rounded-lg transition-all duration-200">
              Find More Friends
            </button>
          </div>
        </div>
      )}

      {/* Learning Section */}
      {activeSection === 'learning' && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center space-x-2">
              <BookOpen className="w-6 h-6 text-green-600" />
              <span>Art Tutorials</span>
            </h3>
            <div className="space-y-4">
              {tutorials.map((tutorial, index) => (
                <div key={index} className={`flex items-center space-x-4 p-4 rounded-lg border-2 transition-all duration-200 ${
                  tutorial.completed 
                    ? 'bg-green-50 border-green-200' 
                    : 'bg-gray-50 border-gray-200 hover:border-purple-300'
                }`}>
                  <div className="text-2xl">{tutorial.icon}</div>
                  <div className="flex-1">
                    <div className={`font-medium ${tutorial.completed ? 'text-green-800' : 'text-gray-800'}`}>
                      {tutorial.title}
                    </div>
                    <div className="text-sm text-gray-600">{tutorial.duration}</div>
                  </div>
                  {tutorial.completed ? (
                    <div className="text-green-600">
                      <Award size={20} />
                    </div>
                  ) : (
                    <button className="px-4 py-2 bg-purple-500 text-white text-sm font-medium rounded-lg hover:bg-purple-600 transition-all duration-200">
                      Start
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center space-x-2">
              <Zap className="w-6 h-6 text-yellow-500" />
              <span>Skill Progress</span>
            </h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>Color Theory</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full" style={{ width: '75%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>Drawing Techniques</span>
                  <span>60%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-gradient-to-r from-green-500 to-blue-500 h-2 rounded-full" style={{ width: '60%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>Creativity</span>
                  <span>90%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-gradient-to-r from-pink-500 to-yellow-500 h-2 rounded-full" style={{ width: '90%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Settings Section */}
      {activeSection === 'settings' && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center space-x-2">
              <Settings className="w-6 h-6 text-gray-600" />
              <span>Account Settings</span>
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Bell className="w-5 h-5 text-blue-600" />
                  <div>
                    <div className="font-medium text-gray-800">Notifications</div>
                    <div className="text-sm text-gray-600">Get alerts for new likes and comments</div>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" defaultChecked />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Shield className="w-5 h-5 text-green-600" />
                  <div>
                    <div className="font-medium text-gray-800">Privacy Mode</div>
                    <div className="text-sm text-gray-600">Only friends can see your artwork</div>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                </label>
              </div>

              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Camera className="w-5 h-5 text-purple-600" />
                  <div>
                    <div className="font-medium text-gray-800">Auto-Save Drawings</div>
                    <div className="text-sm text-gray-600">Automatically save your work</div>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" defaultChecked />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                </label>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-800 mb-4">Parent Dashboard</h3>
            <div className="space-y-3">
              <button className="w-full flex items-center space-x-3 p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-all duration-200">
                <DollarSign className="w-5 h-5 text-blue-600" />
                <span className="text-blue-800 font-medium">View Earnings Report</span>
              </button>
              <button className="w-full flex items-center space-x-3 p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-all duration-200">
                <Shield className="w-5 h-5 text-green-600" />
                <span className="text-green-800 font-medium">Safety & Privacy Settings</span>
              </button>
              <button className="w-full flex items-center space-x-3 p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-all duration-200">
                <Calendar className="w-5 h-5 text-purple-600" />
                <span className="text-purple-800 font-medium">Set Drawing Time Limits</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {activeSection === 'overview' && (
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Recent Earnings */}
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <TrendingUp className="w-6 h-6 text-green-600" />
                <h3 className="text-xl font-bold text-gray-800">Recent Earnings</h3>
              </div>
              <button className="text-green-600 text-sm font-medium hover:text-green-700">View All</button>
            </div>
            <div className="space-y-3">
              {recentEarnings.map((earning, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-all duration-200">
                  <div>
                    <div className="font-medium text-gray-800">{earning.drawing}</div>
                    <div className="text-sm text-gray-600">{earning.date}</div>
                  </div>
                  <div className="font-bold text-green-600">{earning.amount}</div>
                </div>
              ))}
            </div>
            <div className="mt-4 p-4 bg-green-50 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="font-medium text-green-800">Total This Week</span>
                <span className="text-xl font-bold text-green-700">1,190 Tsh</span>
              </div>
            </div>
          </div>

          {/* Achievements */}
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <div className="flex items-center space-x-3 mb-6">
              <Award className="w-6 h-6 text-purple-600" />
              <h3 className="text-xl font-bold text-gray-800">Achievements</h3>
            </div>
            <div className="space-y-3">
              {achievements.map((achievement, index) => (
                <div
                  key={index}
                  className={`flex items-center space-x-4 p-3 rounded-lg transition-all duration-200 ${
                    achievement.earned 
                      ? 'bg-green-50 border border-green-200' 
                      : 'bg-gray-50 border border-gray-200 opacity-60'
                  }`}
                >
                  <div className="text-2xl">{achievement.icon}</div>
                  <div className="flex-1">
                    <div className={`font-medium ${achievement.earned ? 'text-green-800' : 'text-gray-600'}`}>
                      {achievement.title}
                    </div>
                    <div className={`text-sm ${achievement.earned ? 'text-green-600' : 'text-gray-500'}`}>
                      {achievement.description}
                    </div>
                  </div>
                  {achievement.earned && (
                    <div className="text-green-600">
                      <Award size={20} />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeSection === 'overview' && (
        <>
          {/* Weekly Rewards */}
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center space-x-2">
              <Gift className="w-6 h-6 text-pink-600" />
              <span>Weekly Rewards</span>
            </h3>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-pink-50 rounded-lg border border-pink-200">
                <div className="text-3xl mb-2">🎁</div>
                <div className="font-bold text-pink-800">Daily Login</div>
                <div className="text-sm text-pink-600">+50 Tsh bonus</div>
                <div className="text-xs text-pink-500 mt-1">5/7 days</div>
              </div>
              <div className="text-center p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-3xl mb-2">🏆</div>
                <div className="font-bold text-blue-800">Weekly Challenge</div>
                <div className="text-sm text-blue-600">+200 Tsh bonus</div>
                <div className="text-xs text-blue-500 mt-1">2/3 completed</div>
              </div>
              <div className="text-center p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                <div className="text-3xl mb-2">⭐</div>
                <div className="font-bold text-yellow-800">Quality Bonus</div>
                <div className="text-sm text-yellow-600">+100 Tsh bonus</div>
                <div className="text-xs text-yellow-500 mt-1">High-quality art</div>
              </div>
            </div>
          </div>

          {/* Progress to Next Level */}
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center space-x-2">
              <Star className="w-6 h-6 text-yellow-500" />
              <span>Progress to Level 4</span>
            </h3>
            <div className="mb-4">
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span>7 more drawings needed</span>
                <span>28/35 drawings</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-gradient-to-r from-purple-500 to-pink-500 h-3 rounded-full transition-all duration-500"
                  style={{ width: '80%' }}
                ></div>
              </div>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-3 bg-yellow-50 rounded-lg">
                <div className="font-medium text-yellow-800">Level 4 Benefits:</div>
                <div className="text-sm text-yellow-700">• 50% more coins per drawing</div>
                <div className="text-sm text-yellow-700">• Special artist badge</div>
                <div className="text-sm text-yellow-700">• Priority in challenges</div>
              </div>
              <div className="p-3 bg-purple-50 rounded-lg">
                <div className="font-medium text-purple-800">Next Milestone:</div>
                <div className="text-sm text-purple-700">• Unlock premium tools</div>
                <div className="text-sm text-purple-700">• Join artist mentorship</div>
                <div className="text-sm text-purple-700">• Monthly art supplies</div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default Profile;