import React from 'react';
import { Palette, Star, Coins, Bell } from 'lucide-react';

interface HeaderProps {
  user: any;
}

const Header: React.FC<HeaderProps> = ({ user }) => {
  return (
    <header className="bg-white shadow-lg border-b-4 border-gradient-to-r from-purple-400 via-pink-400 to-yellow-400">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="bg-gradient-to-r from-purple-500 via-pink-500 to-yellow-500 rounded-full p-3 animate-pulse">
              <Palette className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-yellow-600 bg-clip-text text-transparent">
                KidsArt Studio
              </h1>
              <p className="text-sm text-gray-600 font-medium">Where Creativity Meets Rewards!</p>
            </div>
          </div>

          {user && (
            <div className="flex items-center space-x-4">
              <div className="hidden md:flex items-center space-x-4">
                <div className="flex items-center space-x-2 bg-yellow-100 rounded-full px-4 py-2 border-2 border-yellow-300">
                  <Coins className="w-5 h-5 text-yellow-600" />
                  <span className="font-bold text-yellow-700">2,450 Tsh</span>
                </div>
                <div className="flex items-center space-x-2 bg-purple-100 rounded-full px-4 py-2 border-2 border-purple-300">
                  <Star className="w-5 h-5 text-purple-600" />
                  <span className="font-bold text-purple-700">Level 3 Artist</span>
                </div>
                <button className="bg-blue-100 hover:bg-blue-200 rounded-full p-2 transition-all duration-200">
                  <Bell className="w-5 h-5 text-blue-600" />
                </button>
              </div>
              <div className="w-12 h-12 bg-gradient-to-r from-purple-400 via-pink-400 to-yellow-400 rounded-full flex items-center justify-center border-2 border-white shadow-lg">
                <span className="text-white font-bold text-lg">
                  {user.name.charAt(0).toUpperCase()}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;