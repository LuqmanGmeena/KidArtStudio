import React, { useState } from 'react';
import { CreditCard, Star, Check, Gift, Palette, TrendingUp } from 'lucide-react';

interface SubscriptionProps {
  onUserLogin: (user: any) => void;
  onSubscribe: (status: boolean) => void;
  user?: any;
}

const Subscription: React.FC<SubscriptionProps> = ({ onUserLogin, onSubscribe, user }) => {
  const [showLogin, setShowLogin] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    parent_phone: '',
    password: ''
  });

  const benefits = [
    { icon: Palette, title: 'Unlimited Drawing', description: 'Create as many artworks as you want' },
    { icon: TrendingUp, title: 'Earn Real Money', description: 'Get paid for your creative drawings' },
    { icon: Star, title: 'Special Tools', description: 'Access premium brushes and effects' },
    { icon: Gift, title: 'Daily Challenges', description: 'Win bonus coins with fun themes' }
  ];

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const newUser = {
      name: formData.name,
      age: formData.age,
      parent_phone: formData.parent_phone
    };
    onUserLogin(newUser);
    setShowPayment(true);
  };

  const handleSubscription = () => {
    onSubscribe(true);
  };

  if (user && showPayment) {
    return (
      <div className="max-w-md mx-auto">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="bg-gradient-to-r from-green-500 to-blue-500 p-6 text-white text-center">
            <CreditCard className="w-16 h-16 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Activate Your Account</h2>
            <p className="text-green-100">Join thousands of young artists!</p>
          </div>

          <div className="p-6">
            <div className="text-center mb-6">
              <div className="text-4xl font-bold text-gray-800 mb-2">30 Tsh</div>
              <p className="text-gray-600">One-time activation fee</p>
            </div>

            <div className="space-y-4 mb-6">
              <h3 className="font-bold text-gray-800">What you get:</h3>
              <div className="space-y-3">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="bg-green-100 rounded-full p-2">
                      <Check className="w-4 h-4 text-green-600" />
                    </div>
                    <div>
                      <div className="font-medium text-gray-800">{benefit.title}</div>
                      <div className="text-sm text-gray-600">{benefit.description}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-sm text-yellow-800">
                  <strong>Parent's Note:</strong> This is a one-time fee. Your child can earn money by creating artwork that gets views and likes from other users.
                </p>
              </div>

              <button
                onClick={handleSubscription}
                className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white font-bold py-4 rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                Pay 30 Tsh & Start Creating!
              </button>

              <p className="text-xs text-gray-500 text-center">
                Secure payment • Cancel anytime • Parent supervised
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      {!showLogin ? (
        <div className="text-center">
          <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
            <div className="w-20 h-20 bg-gradient-to-r from-purple-500 via-pink-500 to-yellow-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <Palette className="w-10 h-10 text-white" />
            </div>
            
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-yellow-600 bg-clip-text text-transparent mb-4">
              Welcome to KidsArt Studio!
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Draw your daily environment and earn real money for your creativity!
            </p>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {benefits.map((benefit, index) => (
                <div key={index} className="text-center p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-all duration-200">
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-3">
                    <benefit.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-bold text-gray-800 mb-2">{benefit.title}</h3>
                  <p className="text-sm text-gray-600">{benefit.description}</p>
                </div>
              ))}
            </div>

            <button
              onClick={() => setShowLogin(true)}
              className="bg-gradient-to-r from-purple-500 via-pink-500 to-yellow-500 hover:from-purple-600 hover:via-pink-600 hover:to-yellow-600 text-white font-bold py-4 px-8 rounded-full text-lg transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Get Started - Only 30 Tsh!
            </button>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">How It Works</h2>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-4xl mb-3">🎨</div>
                <h3 className="font-bold text-gray-800 mb-2">1. Create Art</h3>
                <p className="text-gray-600">Draw your daily environment using our fun tools</p>
              </div>
              <div className="text-center">
                <div className="text-4xl mb-3">👀</div>
                <h3 className="font-bold text-gray-800 mb-2">2. Get Views</h3>
                <p className="text-gray-600">Other kids and parents view and like your artwork</p>
              </div>
              <div className="text-center">
                <div className="text-4xl mb-3">💰</div>
                <h3 className="font-bold text-gray-800 mb-2">3. Earn Money</h3>
                <p className="text-gray-600">Get paid real money for popular drawings</p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="max-w-md mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Palette className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-gray-800">Join Our Art Community</h2>
              <p className="text-gray-600">Create your account to start earning!</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Your Name</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="Enter your name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Your Age</label>
                <select
                  required
                  value={formData.age}
                  onChange={(e) => setFormData({...formData, age: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="">Select your age</option>
                  {[5,6,7,8,9,10,11,12,13,14,15].map(age => (
                    <option key={age} value={age}>{age} years old</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Parent's Phone</label>
                <input
                  type="tel"
                  required
                  value={formData.parent_phone}
                  onChange={(e) => setFormData({...formData, parent_phone: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="+255 123 456 789"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Create Password</label>
                <input
                  type="password"
                  required
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="Choose a safe password"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold py-4 rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                Continue to Payment
              </button>
            </form>

            <button
              onClick={() => setShowLogin(false)}
              className="w-full mt-4 text-gray-600 hover:text-gray-800 font-medium py-2 transition-all duration-200"
            >
              Back to Home
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Subscription;