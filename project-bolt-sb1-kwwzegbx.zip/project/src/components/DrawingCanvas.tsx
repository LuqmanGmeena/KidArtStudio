import React, { useRef, useEffect, useState } from 'react';
import { Brush, Eraser, Circle, Square, Download, Trash2, Sparkles, Palette } from 'lucide-react';

const DrawingCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [tool, setTool] = useState('brush');
  const [color, setColor] = useState('#FF6B6B');
  const [brushSize, setBrushSize] = useState(8);
  const [showTip, setShowTip] = useState(true);

  const colors = [
    '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
    '#DDA0DD', '#98D8C8', '#FFB6C1', '#87CEEB', '#F0E68C',
    '#FFA07A', '#20B2AA', '#FF69B4', '#00CED1', '#FF1493',
    '#32CD32', '#FF4500', '#DA70D6', '#40E0D0', '#FF6347'
  ];

  const tools = [
    { id: 'brush', icon: Brush, label: 'Brush', color: 'from-blue-500 to-blue-600' },
    { id: 'eraser', icon: Eraser, label: 'Eraser', color: 'from-gray-500 to-gray-600' },
    { id: 'circle', icon: Circle, label: 'Circle', color: 'from-green-500 to-green-600' },
    { id: 'square', icon: Square, label: 'Square', color: 'from-purple-500 to-purple-600' },
  ];

  const dailyThemes = [
    "Draw your home and garden",
    "Show your school playground",
    "Paint the view from your window",
    "Create your neighborhood street",
    "Draw your favorite outdoor place"
  ];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = 800;
    canvas.height = 600;
    
    // Set background
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add subtle grid
    ctx.strokeStyle = '#f0f0f0';
    ctx.lineWidth = 1;
    for (let i = 0; i < canvas.width; i += 40) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, canvas.height);
      ctx.stroke();
    }
    for (let i = 0; i < canvas.height; i += 40) {
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(canvas.width, i);
      ctx.stroke();
    }
  }, []);

  const getMousePos = (e: React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };

    const rect = canvas.getBoundingClientRect();
    return {
      x: (e.clientX - rect.left) * (canvas.width / rect.width),
      y: (e.clientY - rect.top) * (canvas.height / rect.height)
    };
  };

  const startDrawing = (e: React.MouseEvent) => {
    setIsDrawing(true);
    const { x, y } = getMousePos(e);
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const draw = (e: React.MouseEvent) => {
    if (!isDrawing) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getMousePos(e);

    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (tool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = color;
    }

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  };

  const downloadDrawing = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = `my-drawing-${Date.now()}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  return (
    <div className="space-y-6">
      {/* Daily Challenge */}
      <div className="bg-gradient-to-r from-purple-500 via-pink-500 to-yellow-500 rounded-2xl p-6 text-white">
        <div className="flex items-center space-x-3 mb-3">
          <Sparkles className="w-6 h-6" />
          <h2 className="text-xl font-bold">Today's Challenge</h2>
        </div>
        <p className="text-lg font-medium">{dailyThemes[Math.floor(Math.random() * dailyThemes.length)]}</p>
        <p className="text-sm opacity-90 mt-2">Complete this challenge to earn 200 Tsh!</p>
      </div>

      {showTip && (
        <div className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded-lg">
          <div className="flex items-start space-x-3">
            <div className="flex-shrink-0">
              <Sparkles className="w-5 h-5 text-blue-400 mt-0.5" />
            </div>
            <div className="flex-1">
              <p className="text-blue-800 font-medium">
                Tip: Use bright colors and draw details to earn more money for your artwork!
              </p>
              <button
                onClick={() => setShowTip(false)}
                className="text-blue-600 text-sm underline hover:text-blue-800 mt-1"
              >
                Got it!
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="grid lg:grid-cols-4 gap-6">
        {/* Tools Section */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl p-4 shadow-md">
            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center space-x-2">
              <Palette className="w-5 h-5" />
              <span>Tools</span>
            </h3>
            <div className="space-y-2">
              {tools.map(({ id, icon: Icon, label, color: toolColor }) => (
                <button
                  key={id}
                  onClick={() => setTool(id)}
                  className={`w-full flex items-center space-x-3 p-3 rounded-lg transition-all duration-200 ${
                    tool === id
                      ? `bg-gradient-to-r ${toolColor} text-white shadow-lg transform scale-105`
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-700 hover:scale-105'
                  }`}
                >
                  <Icon size={18} />
                  <span className="font-medium">{label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl p-4 shadow-md">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Colors</h3>
            <div className="grid grid-cols-4 gap-2">
              {colors.map((colorOption) => (
                <button
                  key={colorOption}
                  onClick={() => setColor(colorOption)}
                  className={`w-10 h-10 rounded-full transition-all duration-200 hover:scale-110 ${
                    color === colorOption ? 'ring-3 ring-gray-400 transform scale-110' : 'hover:ring-2 hover:ring-gray-300'
                  }`}
                  style={{ backgroundColor: colorOption }}
                />
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl p-4 shadow-md">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Brush Size</h3>
            <input
              type="range"
              min="2"
              max="25"
              value={brushSize}
              onChange={(e) => setBrushSize(Number(e.target.value))}
              className="w-full accent-purple-500"
            />
            <div className="text-center mt-2 text-gray-600 font-medium">{brushSize}px</div>
          </div>

          <div className="bg-white rounded-xl p-4 shadow-md space-y-3">
            <button
              onClick={clearCanvas}
              className="w-full flex items-center justify-center space-x-2 p-3 bg-red-100 hover:bg-red-200 text-red-700 rounded-lg transition-all duration-200 hover:scale-105"
            >
              <Trash2 size={18} />
              <span>Clear</span>
            </button>
            <button
              onClick={downloadDrawing}
              className="w-full flex items-center justify-center space-x-2 p-3 bg-green-100 hover:bg-green-200 text-green-700 rounded-lg transition-all duration-200 hover:scale-105"
            >
              <Download size={18} />
              <span>Download</span>
            </button>
          </div>
        </div>

        {/* Canvas Section */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <div className="text-center mb-4">
              <h2 className="text-2xl font-bold text-gray-800 mb-2">Your Canvas</h2>
              <p className="text-gray-600">Let your imagination run wild!</p>
            </div>
            
            <div className="flex justify-center">
              <div className="border-4 border-gray-200 rounded-lg overflow-hidden shadow-md">
                <canvas
                  ref={canvasRef}
                  onMouseDown={startDrawing}
                  onMouseMove={draw}
                  onMouseUp={stopDrawing}
                  onMouseLeave={stopDrawing}
                  className="cursor-crosshair bg-white"
                  style={{ 
                    width: '100%', 
                    maxWidth: '700px', 
                    height: 'auto',
                    aspectRatio: '4/3'
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DrawingCanvas;