import React from 'react';
import { Heart, Eye, DollarSign, Trophy, Star, Search, Filter, Share2, Download, MessageCircle, ThumbsUp } from 'lucide-react';

const Gallery: React.FC = () => {
  const artworks = [
    {
      id: 1,
      title: "My Beautiful Garden",
      artist: "Sarah, Age 8",
      earnings: "450 Tsh",
      views: 234,
      likes: 45,
      image: "https://images.pexels.com/photos/1166209/pexels-photo-1166209.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "Nature"
    },
    {
      id: 2,
      title: "School Playground Fun",
      artist: "Ahmed, Age 10",
      earnings: "680 Tsh",
      views: 189,
      likes: 67,
      image: "https://images.pexels.com/photos/1094065/pexels-photo-1094065.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "School"
    },
    {
      id: 3,
      title: "Sunset from My Window",
      artist: "Grace, Age 9",
      earnings: "520 Tsh",
      views: 312,
      likes: 89,
      image: "https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "Home"
    },
    {
      id: 4,
      title: "Market Day Colors",
      artist: "John, Age 7",
      earnings: "720 Tsh",
      views: 156,
      likes: 92,
      image: "https://images.pexels.com/photos/2317712/pexels-photo-2317712.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "Community"
    },
    {
      id: 5,
      title: "My Pet and Me",
      artist: "Amara, Age 11",
      earnings: "890 Tsh",
      views: 445,
      likes: 123,
      image: "https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "Pets"
    },
    {
      id: 6,
      title: "Rainy Day Adventure",
      artist: "Moses, Age 9",
      earnings: "340 Tsh",
      views: 198,
      likes: 56,
      image: "https://images.pexels.com/photos/459451/pexels-photo-459451.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "Weather"
    }
  ];

  const categories = ["All", "Nature", "School", "Home", "Community", "Pets", "Weather"];
  const [selectedCategory, setSelectedCategory] = React.useState("All");
  const [searchTerm, setSearchTerm] = React.useState("");
  const [sortBy, setSortBy] = React.useState("newest");
  const [showComments, setShowComments] = React.useState<number | null>(null);

  const filteredArtworks = artworks
    .filter(art => selectedCategory === "All" || art.category === selectedCategory)
    .filter(art => art.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                   art.artist.toLowerCase().includes(searchTerm.toLowerCase()))
    .sort((a, b) => {
      switch(sortBy) {
        case 'earnings': return parseInt(b.earnings) - parseInt(a.earnings);
        case 'likes': return b.likes - a.likes;
        case 'views': return b.views - a.views;
        default: return b.id - a.id; // newest first
      }
    });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
          Kids Art Gallery
        </h2>
        <p className="text-gray-600 text-lg">Discover amazing artwork from young artists around the world!</p>
      </div>

      {/* Search and Filter Bar */}
      <div className="bg-white rounded-xl p-4 shadow-lg">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search artworks or artists..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="w-5 h-5 text-gray-600" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            >
              <option value="newest">Newest First</option>
              <option value="earnings">Highest Earnings</option>
              <option value="likes">Most Liked</option>
              <option value="views">Most Viewed</option>
            </select>
          </div>
        </div>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap justify-center gap-3">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-6 py-2 rounded-full font-medium transition-all duration-200 ${
              selectedCategory === category
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg transform scale-105'
                : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200 hover:scale-105'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Top Earners Banner */}
      <div className="bg-gradient-to-r from-yellow-400 via-orange-400 to-red-400 rounded-2xl p-6 text-white">
        <div className="flex items-center space-x-3 mb-3">
          <Trophy className="w-6 h-6" />
          <h3 className="text-xl font-bold">Top Earners This Week</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white bg-opacity-20 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold">🥇</div>
            <div className="font-medium">Sarah</div>
            <div className="text-sm opacity-90">1,250 Tsh</div>
          </div>
          <div className="bg-white bg-opacity-20 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold">🥈</div>
            <div className="font-medium">Ahmed</div>
            <div className="text-sm opacity-90">980 Tsh</div>
          </div>
          <div className="bg-white bg-opacity-20 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold">🥉</div>
            <div className="font-medium">Grace</div>
            <div className="text-sm opacity-90">760 Tsh</div>
          </div>
        </div>
      </div>

      {/* Gallery Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredArtworks.map((artwork) => (
          <div
            key={artwork.id}
            className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:scale-105"
          >
            <div className="relative">
              <div className="w-full h-48 bg-gradient-to-br from-purple-100 to-pink-100 flex items-center justify-center">
                <div className="w-32 h-32 bg-gradient-to-br from-purple-300 to-pink-300 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-lg">🎨</span>
                </div>
              </div>
              <div className="absolute top-3 right-3 bg-white rounded-full px-3 py-1 text-sm font-bold text-purple-600">
                {artwork.category}
              </div>
            </div>
            
            <div className="p-4">
              <h3 className="font-bold text-gray-800 text-lg mb-1">{artwork.title}</h3>
              <p className="text-gray-600 text-sm mb-3">{artwork.artist}</p>
              
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <div className="flex items-center space-x-1">
                    <Eye size={16} />
                    <span>{artwork.views}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Heart size={16} className="text-red-500" />
                    <span>{artwork.likes}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <MessageCircle size={16} className="text-blue-500" />
                    <span>{Math.floor(Math.random() * 20) + 1}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-1 bg-green-100 rounded-full px-3 py-1">
                  <DollarSign size={16} className="text-green-600" />
                  <span className="font-bold text-green-700">{artwork.earnings}</span>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex space-x-2">
                  <button className="flex-1 bg-purple-100 hover:bg-purple-200 text-purple-700 font-medium py-2 rounded-lg transition-all duration-200">
                    View Full
                  </button>
                  <button className="flex items-center justify-center p-2 bg-pink-100 hover:bg-pink-200 text-pink-700 rounded-lg transition-all duration-200">
                    <Heart size={18} />
                  </button>
                  <button 
                    onClick={() => setShowComments(showComments === artwork.id ? null : artwork.id)}
                    className="flex items-center justify-center p-2 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded-lg transition-all duration-200"
                  >
                    <MessageCircle size={18} />
                  </button>
                </div>
                <div className="flex space-x-2">
                  <button className="flex items-center justify-center space-x-1 flex-1 bg-green-100 hover:bg-green-200 text-green-700 font-medium py-2 rounded-lg transition-all duration-200">
                    <Share2 size={16} />
                    <span>Share</span>
                  </button>
                  <button className="flex items-center justify-center space-x-1 flex-1 bg-yellow-100 hover:bg-yellow-200 text-yellow-700 font-medium py-2 rounded-lg transition-all duration-200">
                    <Download size={16} />
                    <span>Save</span>
                  </button>
                </div>
              </div>

              {/* Comments Section */}
              {showComments === artwork.id && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <div className="space-y-3 max-h-32 overflow-y-auto">
                    <div className="flex items-start space-x-2">
                      <div className="w-6 h-6 bg-blue-400 rounded-full flex items-center justify-center text-white text-xs font-bold">M</div>
                      <div className="flex-1">
                        <div className="text-sm font-medium text-gray-800">Maria, Age 9</div>
                        <div className="text-sm text-gray-600">So beautiful! I love the colors! 🌈</div>
                      </div>
                    </div>
                    <div className="flex items-start space-x-2">
                      <div className="w-6 h-6 bg-green-400 rounded-full flex items-center justify-center text-white text-xs font-bold">D</div>
                      <div className="flex-1">
                        <div className="text-sm font-medium text-gray-800">David, Age 10</div>
                        <div className="text-sm text-gray-600">Amazing work! Can you teach me? 🎨</div>
                      </div>
                    </div>
                  </div>
                  <div className="mt-3 flex space-x-2">
                    <input
                      type="text"
                      placeholder="Write a nice comment..."
                      className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                    <button className="px-4 py-2 bg-purple-500 text-white text-sm font-medium rounded-lg hover:bg-purple-600 transition-all duration-200">
                      Send
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Featured Artist Section */}
      <div className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-2xl p-6 text-white">
        <h3 className="text-2xl font-bold mb-4 flex items-center space-x-2">
          <Star className="w-6 h-6" />
          <span>Featured Artist of the Day</span>
        </h3>
        <div className="bg-white bg-opacity-20 rounded-xl p-4">
          <div className="flex items-center space-x-4 mb-4">
            <div className="w-16 h-16 bg-white bg-opacity-30 rounded-full flex items-center justify-center">
              <span className="text-2xl font-bold">S</span>
            </div>
            <div>
              <h4 className="text-xl font-bold">Sarah, Age 8</h4>
              <p className="opacity-90">Nature Art Specialist</p>
            </div>
          </div>
          <p className="mb-4 opacity-90">
            "I love drawing flowers and trees from my backyard. Art makes me happy and now I can save money for my bicycle!"
          </p>
          <div className="flex space-x-4 text-sm">
            <span>🎨 15 Drawings</span>
            <span>💰 1,250 Tsh Earned</span>
            <span>❤️ 234 Total Likes</span>
          </div>
        </div>
      </div>

      {/* Weekly Challenges */}
      <div className="bg-white rounded-xl p-6 shadow-lg">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center space-x-2">
          <Trophy className="w-6 h-6 text-orange-500" />
          <span>Weekly Art Challenges</span>
        </h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-bold text-orange-800">Environment Week</h4>
              <span className="text-xs bg-orange-200 text-orange-800 px-2 py-1 rounded-full">3 days left</span>
            </div>
            <p className="text-sm text-orange-700 mb-3">Draw your neighborhood and win 500 Tsh bonus!</p>
            <div className="text-xs text-orange-600">12 participants • Prize: 500 Tsh</div>
          </div>
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-bold text-blue-800">Weather Art</h4>
              <span className="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded-full">Starting soon</span>
            </div>
            <p className="text-sm text-blue-700 mb-3">Show different weather in your drawings!</p>
            <div className="text-xs text-blue-600">Prize: 300 Tsh • Duration: 5 days</div>
          </div>
        </div>
      </div>

      {/* No results message */}
      {filteredArtworks.length === 0 && (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">🎨</div>
          <h3 className="text-xl font-bold text-gray-800 mb-2">No artwork found</h3>
          <p className="text-gray-600">Try adjusting your search or category filter</p>
        </div>
      )}

      {/* Earning Tips */}
      <div className="bg-white rounded-2xl p-6 shadow-lg">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center space-x-2">
          <Star className="w-6 h-6 text-yellow-500" />
          <span>How to Earn More</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-3xl mb-2">🎨</div>
            <h4 className="font-bold text-blue-800 mb-1">Be Creative</h4>
            <p className="text-blue-600 text-sm">Use lots of colors and details</p>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-3xl mb-2">📅</div>
            <h4 className="font-bold text-green-800 mb-1">Daily Challenges</h4>
            <p className="text-green-600 text-sm">Complete themes for bonus coins</p>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <div className="text-3xl mb-2">👥</div>
            <h4 className="font-bold text-purple-800 mb-1">Get Likes</h4>
            <p className="text-purple-600 text-sm">Popular drawings earn more</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Gallery;