import React, { useState } from 'react';
import { TrendingUp, DollarSign, Calendar, Download, Eye, Heart, Award, Target, Zap, Gift } from 'lucide-react';

interface EarningsPageProps {
  user: any;
}

const EarningsPage: React.FC<EarningsPageProps> = ({ user }) => {
  const [timeFilter, setTimeFilter] = useState('week');
  const [showWithdraw, setShowWithdraw] = useState(false);

  const earningsData = {
    week: { total: '1,190 Tsh', drawings: 8, avgPerDrawing: '149 Tsh' },
    month: { total: '4,850 Tsh', drawings: 28, avgPerDrawing: '173 Tsh' },
    all: { total: '12,450 Tsh', drawings: 67, avgPerDrawing: '186 Tsh' }
  };

  const detailedEarnings = [
    { 
      drawing: 'Sunset Garden', 
      amount: '180 Tsh', 
      date: 'Today', 
      views: 45, 
      likes: 12, 
      comments: 3,
      category: 'Nature',
      status: 'earning'
    },
    { 
      drawing: 'My School', 
      amount: '220 Tsh', 
      date: 'Yesterday', 
      views: 67, 
      likes: 18, 
      comments: 5,
      category: 'School',
      status: 'earning'
    },
    { 
      drawing: 'Rain Day', 
      amount: '160 Tsh', 
      date: '2 days ago', 
      views: 34, 
      likes: 8, 
      comments: 2,
      category: 'Weather',
      status: 'earning'
    },
    { 
      drawing: 'Family Picnic', 
      amount: '290 Tsh', 
      date: '3 days ago', 
      views: 89, 
      likes: 25, 
      comments: 7,
      category: 'Family',
      status: 'earning'
    },
    { 
      drawing: 'City Street', 
      amount: '340 Tsh', 
      date: '4 days ago', 
      views: 112, 
      likes: 34, 
      comments: 9,
      category: 'Community',
      status: 'earning'
    }
  ];

  const withdrawalMethods = [
    { name: 'M-Pesa', fee: '0 Tsh', time: 'Instant', icon: '📱' },
    { name: 'Bank Transfer', fee: '100 Tsh', time: '1-2 days', icon: '🏦' },
    { name: 'Airtel Money', fee: '0 Tsh', time: 'Instant', icon: '📲' }
  ];

  const currentData = earningsData[timeFilter as keyof typeof earningsData];

  return (
    <div className="space-y-6">
      {/* Earnings Header */}
      <div className="bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 rounded-2xl p-6 text-white">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Your Earnings</h1>
            <p className="text-lg opacity-90">Keep creating amazing art to earn more!</p>
          </div>
          <div className="mt-4 md:mt-0 text-center">
            <div className="text-4xl font-bold">{currentData.total}</div>
            <div className="text-sm opacity-90">Total Earned</div>
          </div>
        </div>
      </div>

      {/* Time Filter */}
      <div className="flex justify-center">
        <div className="bg-white rounded-full p-2 shadow-lg flex space-x-2">
          {[
            { id: 'week', label: 'This Week' },
            { id: 'month', label: 'This Month' },
            { id: 'all', label: 'All Time' }
          ].map((filter) => (
            <button
              key={filter.id}
              onClick={() => setTimeFilter(filter.id)}
              className={`px-6 py-2 rounded-full font-medium transition-all duration-200 ${
                timeFilter === filter.id
                  ? 'bg-gradient-to-r from-green-500 to-teal-500 text-white shadow-md'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg text-center">
          <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <DollarSign className="w-6 h-6 text-green-600" />
          </div>
          <div className="text-2xl font-bold text-gray-800">{currentData.total}</div>
          <div className="text-sm text-gray-600">Total Earned</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-lg text-center">
          <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <Target className="w-6 h-6 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-gray-800">{currentData.drawings}</div>
          <div className="text-sm text-gray-600">Drawings Sold</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-lg text-center">
          <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <TrendingUp className="w-6 h-6 text-purple-600" />
          </div>
          <div className="text-2xl font-bold text-gray-800">{currentData.avgPerDrawing}</div>
          <div className="text-sm text-gray-600">Avg per Drawing</div>
        </div>
      </div>

      {/* Withdrawal Section */}
      <div className="bg-white rounded-xl p-6 shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-gray-800 flex items-center space-x-2">
            <DollarSign className="w-6 h-6 text-green-600" />
            <span>Withdraw Money</span>
          </h3>
          <div className="text-right">
            <div className="text-sm text-gray-600">Available Balance</div>
            <div className="text-2xl font-bold text-green-600">2,450 Tsh</div>
          </div>
        </div>

        {!showWithdraw ? (
          <div className="text-center">
            <p className="text-gray-600 mb-4">Minimum withdrawal: 500 Tsh</p>
            <button
              onClick={() => setShowWithdraw(true)}
              className="bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 text-white font-bold py-3 px-8 rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              Withdraw Money
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              {withdrawalMethods.map((method, index) => (
                <div key={index} className="p-4 border-2 border-gray-200 rounded-lg hover:border-green-400 cursor-pointer transition-all duration-200">
                  <div className="text-center">
                    <div className="text-3xl mb-2">{method.icon}</div>
                    <div className="font-bold text-gray-800">{method.name}</div>
                    <div className="text-sm text-gray-600">Fee: {method.fee}</div>
                    <div className="text-xs text-gray-500">{method.time}</div>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex space-x-4">
              <input
                type="number"
                placeholder="Amount (min 500 Tsh)"
                min="500"
                max="2450"
                className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              />
              <button className="bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-lg transition-all duration-200">
                Request
              </button>
            </div>
            <button
              onClick={() => setShowWithdraw(false)}
              className="w-full text-gray-600 hover:text-gray-800 py-2"
            >
              Cancel
            </button>
          </div>
        )}
      </div>

      {/* Detailed Earnings List */}
      <div className="bg-white rounded-xl p-6 shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-gray-800">Earnings History</h3>
          <button className="flex items-center space-x-2 bg-blue-100 hover:bg-blue-200 text-blue-700 font-medium py-2 px-4 rounded-lg transition-all duration-200">
            <Download size={16} />
            <span>Export</span>
          </button>
        </div>
        <div className="space-y-3">
          {detailedEarnings.map((earning, index) => (
            <div key={index} className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-all duration-200">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-pink-400 rounded-lg flex items-center justify-center">
                    <span className="text-white font-bold text-sm">🎨</span>
                  </div>
                  <div>
                    <div className="font-medium text-gray-800">{earning.drawing}</div>
                    <div className="text-sm text-gray-600">{earning.date} • {earning.category}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-green-600 text-lg">{earning.amount}</div>
                  <div className={`text-xs px-2 py-1 rounded-full ${
                    earning.status === 'earning' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'
                  }`}>
                    {earning.status}
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-6 text-sm text-gray-600">
                <div className="flex items-center space-x-1">
                  <Eye size={14} />
                  <span>{earning.views} views</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Heart size={14} className="text-red-500" />
                  <span>{earning.likes} likes</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Award size={14} className="text-yellow-500" />
                  <span>{Math.round((earning.likes / earning.views) * 100)}% engagement</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Earning Goals */}
      <div className="bg-white rounded-xl p-6 shadow-lg">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center space-x-2">
          <Target className="w-6 h-6 text-blue-600" />
          <span>Monthly Goals</span>
        </h3>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>Goal: 5,000 Tsh this month</span>
              <span>4,850 / 5,000 Tsh (97%)</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div 
                className="bg-gradient-to-r from-blue-500 to-purple-500 h-3 rounded-full transition-all duration-500"
                style={{ width: '97%' }}
              ></div>
            </div>
            <p className="text-sm text-gray-600 mt-2">Just 150 Tsh more to reach your goal! 🎯</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-4 mt-6">
            <div className="p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Zap className="w-5 h-5 text-blue-600" />
                <span className="font-bold text-blue-800">Quick Tip</span>
              </div>
              <p className="text-sm text-blue-700">Draw during peak hours (4-7 PM) to get more views!</p>
            </div>
            <div className="p-4 bg-purple-50 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Gift className="w-5 h-5 text-purple-600" />
                <span className="font-bold text-purple-800">Bonus Alert</span>
              </div>
              <p className="text-sm text-purple-700">Complete 3 more drawings this week for 200 Tsh bonus!</p>
            </div>
          </div>
        </div>
      </div>

      {/* Earnings Analytics */}
      <div className="bg-white rounded-xl p-6 shadow-lg">
        <h3 className="text-xl font-bold text-gray-800 mb-4">Performance Analytics</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium text-gray-700 mb-3">Best Performing Categories</h4>
            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                <span className="text-sm text-green-800">Nature Scenes</span>
                <span className="text-sm font-bold text-green-700">avg 195 Tsh</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-blue-50 rounded">
                <span className="text-sm text-blue-800">School Life</span>
                <span className="text-sm font-bold text-blue-700">avg 178 Tsh</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-purple-50 rounded">
                <span className="text-sm text-purple-800">Community</span>
                <span className="text-sm font-bold text-purple-700">avg 165 Tsh</span>
              </div>
            </div>
          </div>
          <div>
            <h4 className="font-medium text-gray-700 mb-3">Best Drawing Times</h4>
            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 bg-orange-50 rounded">
                <span className="text-sm text-orange-800">4:00 - 7:00 PM</span>
                <span className="text-sm font-bold text-orange-700">Peak views</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-yellow-50 rounded">
                <span className="text-sm text-yellow-800">Weekend mornings</span>
                <span className="text-sm font-bold text-yellow-700">High engagement</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-pink-50 rounded">
                <span className="text-sm text-pink-800">After school</span>
                <span className="text-sm font-bold text-pink-700">More likes</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EarningsPage;